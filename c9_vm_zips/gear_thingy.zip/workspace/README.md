NOTES:

: <<'END_OF_COMMENT'

function date_and_time_with_milliseconds(){
    echo $(date +%D:%T:%N);
}
repo_clone_start_time=$(date_and_time_with_milliseconds)
repo_clone_end_time=$(date_and_time_with_milliseconds)
echo "" >> "$cleanup_directory/c9_vm_zips/c9_cleanup_log.txt"
echo "-----------------------------------------------------------" >> "$cleanup_directory/c9_vm_zips/c9_cleanup_log.txt"
echo "Clean up of C9 VM : $C9_PROJECT started at $start_time" >> "$cleanup_directory/c9_vm_zips/c9_cleanup_log.txt"
echo "" >> "$cleanup_directory/c9_vm_zips/c9_cleanup_log.txt"
zip_start_time=$(date_and_time_with_milliseconds)
zip_end_time=$(date_and_time_with_milliseconds)
echo "" >> "$cleanup_directory/c9_vm_zips/c9_cleanup_log.txt"
clean_up_end_time=$(date_and_time_with_milliseconds)
echo "Clean up of C9 VM : $C9_PROJECT finished at $clean_up_end_time" >> "$cleanup_directory/c9_vm_zips/c9_cleanup_log.txt"
#git add --all
#git commit -m "Scripted clean up of $C9_PROJECT"
#git push --all
#zip -r "$GOPATH/$zip_file_name" "workspace"* -x *ewha_spring_2016_cleanup*

#echo "Today is $(date)"
END_OF_COMMENT