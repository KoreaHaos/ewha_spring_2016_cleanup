#### Cleanup Repos (need to be made):

* z_backyard_ewha_30490_metal_and_expression
* z_backyard_ewha_36564_basic_engineeirng_design_for_electronics_engineering
* z_backyard_ewha_37269_smart_software_project
* z_backyard_ewha_38046_financial_technology

#### Taken Course Title and Professor:

* 30490-01_Metal and Expression KIM JONG KU Prof.
* 36564-01_Basic Engineeirng Design for Electronics Engineering Jewon Kang Prof.
* 37269-01_Smart Software Project HyungJune Lee Prof.
* 38046-01_Financial Technology Seth Huang Prof.
